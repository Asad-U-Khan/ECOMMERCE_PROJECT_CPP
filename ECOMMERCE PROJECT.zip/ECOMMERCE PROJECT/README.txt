Basically this is an ecommerce project 
Helpline files reads the FAQs
Shop file holds the record of shop items
PASSWORD "ASAD ULLAH KHAN"
Kindly Support and get connected with me
Thanking you !